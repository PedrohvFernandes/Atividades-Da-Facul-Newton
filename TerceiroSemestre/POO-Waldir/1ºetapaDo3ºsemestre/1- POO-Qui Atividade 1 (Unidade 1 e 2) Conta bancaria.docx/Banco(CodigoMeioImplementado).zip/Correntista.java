public class Correntista {
  private String nome;
  private String cpf;
  private String dataNasc;

public Correntista(String nome, String cpf, String dataNasc){
        
        this.nome = nome;
        this.cpf = cpf;
        this.dataNasc = dataNasc;

    }


public String getNome() {
        return nome;
    }

public String getCpf(){
        return cpf;
    }

public String getDataNasc(){
      return dataNasc;
}
  
}