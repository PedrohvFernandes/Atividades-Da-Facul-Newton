import java.util.Scanner;

public class ContaBancaria {
  
  private String banco;
  private String agencia;
  private String numero;
  private float saldo;

public ContaBancaria(String banco, String agencia, String numero, float saldo){
        
        this.banco = banco;
        this.agencia = agencia;
        this.numero = numero;
        this.saldo = saldo;

    }

public String getBanco() {
        return banco;
    }

public String getAgencia(){
        return agencia;
    }

public String getNumero(){
      return numero;
    }
    
public float getSaldo(){
      return saldo;
    }

  public void depositar(float valor){

    if (valor <= 0) {
      System.out.println("ERRO: valor inválido para depósito.");

      return;
    }
    else{
    saldo = saldo + valor;
    System.out.println("Saldo atual na conta apos o deposito: " +numero+": R$"+saldo);
    }
  }

public void transferir(float valor){
            if(valor <=0 || saldo <= 0 || valor > saldo){
                System.out.println("ERRO: valor inválido para transferir.");
              }
             else{
              System.out.println("Descontado: "+ valor +" da sua conta");
              saldo-=valor;
              System.out.println("Saldo atual da conta apos transferir: "+numero+": R$"+saldo);
              return;
            }
          
}
public void pagarConta(float valor){
             
             if(valor <=0 || saldo <= 0 || valor > saldo){
                System.out.println("ERRO: valor inválido para pagar a conta.");
              }
             else{
              System.out.println("Descontado: "+ valor +" da sua conta");
              saldo-=valor;
              System.out.println("Saldo atual da conta apos pagar conta: "+numero+": R$"+saldo);
              return;
            }
}

  public void sacar(float valor) {

            if(valor <=0 || saldo <= 0 || valor > saldo){
                System.out.println("ERRO: valor inválido para sacar.");
              }
             else{
              System.out.println("Sacando: "+ valor +" da sua conta: " + numero);
              saldo-=valor;
              System.out.println("Saldo atual da conta após sacar: "+numero+": R$"+saldo);
              return;
            }



  }



}