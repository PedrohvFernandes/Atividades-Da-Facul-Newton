import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int i=1;
    float valor;


System.out.println("Insira os seus dados para Cadastrar a sua conta corrente, nome, cpf e Data de Nascimento");
          
          String nome = input.nextLine();
          String cpf = input.nextLine();
          String dataNasc = input.nextLine();
        
         var usuarioCorrentista = new Correntista(nome, cpf, dataNasc);

         System.out.println(usuarioCorrentista);

System.out.println("Insira os dados da conta bancaria, banco, agencia, numero e saldo");
          
          String banco = input.nextLine();
          String agencia = input.nextLine();
          String numero = input.nextLine();
          float saldo = input.nextFloat();

          var contaBancaria = new ContaBancaria(banco, agencia, numero, saldo);
          
          System.out.println(contaBancaria);
      

while( i != 8 ){
        System.out.println("Qual operação deseja realizar?");
        System.out.println("1 - Mostrar dados pessoais da conta");
        System.out.println("2 - Sacar");
        System.out.println("3 - Depositar");
        System.out.println("4 - Transferir");
        System.out.println("5 - Pagar conta");
        System.out.println("6 - Exibir saldo");
        System.out.println("7 - Exibir extrato");
        System.out.println("8 - Sair");
        i = input.nextInt();
          //i = Float.parseFloat(input.nextLine());

        switch (i) {
          case 1:
          System.out.println("Usuario: "+ usuarioCorrentista.getNome() + " CPF: " + usuarioCorrentista.getCpf() + " DTA Nascimento: " + usuarioCorrentista.getDataNasc() + "\n" + "Cadastrado no Banco: " + contaBancaria.getBanco() + " Agencia: " + contaBancaria.getAgencia() + " Numero da conta: " + contaBancaria.getNumero() + " Possui o saldo: " + contaBancaria.getSaldo());

          break;

          case 2:
          System.out.println("Saldo atual da conta: "+contaBancaria.getSaldo());

          System.out.println("Qual valor você deseja sacar da sua conta: "+contaBancaria.getNumero());

          valor = input.nextFloat();
          
          contaBancaria.sacar(valor, true); 
          
          break;

          case 3:
          System.out.println("Saldo atual da conta: "+contaBancaria.getSaldo());

          System.out.println("Qual valor a creditar na conta: " +contaBancaria.getNumero()+" : ");

           valor = input.nextFloat(); 

          contaBancaria.depositar(valor);
          break;

          case 4:

          System.out.println("Saldo atual da conta: "+contaBancaria.getSaldo());

          System.out.println("Qual valor a transferir da conta: " + contaBancaria.getNumero()+ " para a conta: 345674-98" );

          valor = input.nextFloat();

          contaBancaria.transferir(valor, "Netflix");
          break;

          case 5:
          System.out.println("Saldo atual da conta: "+contaBancaria.getSaldo());

          System.out.println("Digite um valor a pagar a conta: ");
          valor = input.nextFloat();
          contaBancaria.pagarConta(valor, "PornHub");
          break;

          case 6:
          System.out.println("Saldo disponivel: "+ contaBancaria.getSaldo());
          break;

          case 7:
          contaBancaria.exibirExtrato();
          break;

          case 8:
          System.out.println("Obrigado por usar o nosso software😎");

        }





  }
  }
}