import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    System.out.println("==================================");
    System.out.println("Prova AD - Waldir 2021 POO.Quinta");
    System.out.println("Nome: Pedro Henrique Vieira Fernandes");
    System.out.println("==================================");

    System.out.println("Insira o titulo do filme, ano que foi lançado, qual o estudio de produção, o ator principal e o secundario e por fim a nota que você acha que o filme merece: ");

          String titulo = input.nextLine();
          int ano = input.nextInt();
          input.nextLine();//consome a nova linha de sobra
          String estudio = input.nextLine();
          String atorPrincipal = input.nextLine();
          String atorSecundario = input.nextLine();
          float nota = input.nextFloat();



          var filme1 = new Filme(titulo, ano, estudio, atorPrincipal, atorSecundario, nota);

          System.out.println(filme1);

  }
}