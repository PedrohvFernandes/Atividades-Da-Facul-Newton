public class Filme{

private String titulo;
private int ano;
private String estudio;
private String atorPrincipal;
private String atorSecundario;
private float nota;


public Filme(String titulo, int ano, String estudio, String atorPrincipal, String atorSecundario, float nota){

this.titulo = titulo;
this.ano = ano;
this.estudio = estudio;
this.atorPrincipal = atorPrincipal;
this.atorSecundario = atorSecundario;
this.nota = nota;

}

  @Override
 public String toString() {
        return "Titulo do filme: " + titulo + ", lançado no ano de: " + ano + ", do estudio: " + estudio + ", tendo como ator princiapl: " + atorPrincipal + ", e como ator secundario : " + atorSecundario + " e por ultimo, mas não menos importante a sua avaliação: " + nota;
    }

public String getTitulo(){
  return titulo;
}

public int getAno(){
  return ano;
}

public String getEstudio(){
  return estudio;
}

public String getAtorPrinciapl(){
  return atorPrincipal;
}

public String getAtorSecundario(){
  return atorSecundario;
}

public float getNota(){
  return nota;
}


}