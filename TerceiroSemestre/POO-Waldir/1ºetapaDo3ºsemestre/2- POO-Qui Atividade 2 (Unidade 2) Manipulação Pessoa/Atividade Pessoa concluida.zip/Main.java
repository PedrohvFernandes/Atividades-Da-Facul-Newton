class Main {
  public static void main(String[] args) {

    var pessoa1 = new Pessoa("José das Couves", "123456789-01", "2020/01/01", 35.3f);

    System.out.println(pessoa1);
    System.out.println("Quantidade: " + Pessoa.getQuantidade() + "\n");

    var pessoa2 = new Pessoa("Maria das Couves", "123456789-01", "1998/01/01", 15.3f);

    System.out.println(pessoa2);
    System.out.println("Quantidade: " + Pessoa.getQuantidade() + "\n");

    var pessoa3 = new Pessoa("Marta das Couves", "123456789-01", "2010/01/01", 85.3f);
    
    System.out.println(pessoa3);
    System.out.println("Quantidade: " + Pessoa.getQuantidade() + "\n");

    // assumir que a 1a pessoa é a caçula
    var cacula = pessoa1;

    if (cacula.getDataNasc().compareTo(pessoa2.getDataNasc()) < 0) {
      cacula = pessoa2;
    }

    if (cacula.getDataNasc().compareTo(pessoa3.getDataNasc()) < 0) {
      cacula = pessoa3;
    }
    System.out.println("O caçula é: " + cacula.getNome());

    //Comparando peso, o menor peso
    float peso = pessoa1.getPeso();
        
        if (pessoa2.getPeso() < peso) {
            peso = pessoa2.getPeso();
        }
        if (pessoa3.getPeso() < peso) {
            peso = pessoa3.getPeso();
        }
        
        System.out.println("Menor peso: " + peso);

  }
}