public class Pessoa {
  private static int quantidade = 0;//Adicione uma variável estática na classe que permite contabilizar quantas instâncias da classe Pessoa foram criadas.
  
  private String nome;
  private String dataNasc;
  private float peso;
  private String cpf;

  public Pessoa(String nome, String cpf, String dataNasc, float peso) {
    this.nome = nome;
    this.cpf = cpf;
    this.dataNasc = dataNasc;
    this.peso = peso;

    quantidade++;
  }

  public String toString() {// toString - converte objeto para String
    return "Pessoa nome: " + nome + " CPF: " + cpf
    + " Data de Nascimento: " + dataNasc + " Peso: " + peso + " Kg";
  }

  public String getNome() {
    return nome;
  }

  public String getDataNasc() {
    return dataNasc;
  }

  public float getPeso(){
    return peso;
  }

  public String getCpf(){
    return cpf;
  }

  public static int getQuantidade() {//Adicione uma variável estática na classe que permite contabilizar quantas instâncias da classe Pessoa foram criadas.
        return quantidade;
    }
}